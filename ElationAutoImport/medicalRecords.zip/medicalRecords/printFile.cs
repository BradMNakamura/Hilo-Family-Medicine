﻿

namespace ElationAutoImport
{
    class printFile : GeneralForm
    {
        public printFile(string fileType)
        {
            fileName = fileType;
        }
    }
}
